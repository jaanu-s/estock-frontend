export interface ViewPriceDetail{
    min:number;
    max:number;
    average: number;
}