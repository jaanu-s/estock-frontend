export interface StockPriceBean{
    stckPrice:number;
}